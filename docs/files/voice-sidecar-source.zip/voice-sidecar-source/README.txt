Bible Concordance: the read-aloud voice program (source)

This is the complete source of the separate read-aloud program that comes inside the Bible
Concordance apps for Windows (resources/voice/voice-sidecar). It is a small local server around the
Kokoro text-to-speech model; the app starts it and talks to it over 127.0.0.1 only.

  server.py          the program
  make_voices.py     makes the English-only voices file
  build.ps1          builds the program and the files that go beside it (needs Python 3.12 and PyInstaller)
  requirements.txt   the Python packages it needs

It uses espeak-ng and phonemizer, which are licensed under the GNU General Public License version 3,
so this program as a whole is distributed under the GPL-3.0 (https://www.gnu.org/licenses/gpl-3.0.html).
The unmodified sources of espeak-ng (https://github.com/espeak-ng/espeak-ng) and phonemizer
(https://github.com/bootphon/phonemizer) are available from those projects. The rest of Bible Concordance
is a separate program that only exchanges text and audio with this one.

Credits and licences for everything in the apps: https://bible4me.org/credits/
Made by GhostClaw. Website: https://bible4me.org
